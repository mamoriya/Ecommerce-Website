// focus the cursor on the email-address input
//  Var and let



